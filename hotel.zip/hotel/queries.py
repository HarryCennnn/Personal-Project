queries = {
    "room": {
        "Monthly Meeting Room Revenue in 2023": """
            SELECT 
                DATE_FORMAT(reservation.checkInDate, '%Y-%m') AS Month,
                SUM(sleeping_room.sleepingRoomRate * DATEDIFF(reservation.checkOutDate, reservation.checkInDate)) AS Total_Revenue
            FROM 
                reservation
            JOIN 
                sleeping_room ON reservation.roomId = sleeping_room.sleepingRoomId
            WHERE 
                YEAR(reservation.checkInDate) = 2023
                AND reservation.roomId LIKE 'SR%'
            GROUP BY 
                DATE_FORMAT(reservation.checkInDate, '%Y-%m')
            ORDER BY 
                Month;
        """,
        "Most Popular Room Type": """
            SELECT 
                sleeping_room.sleepingRoomRate AS Room_Rate,
                COUNT(*) AS Reservation_Count
            FROM 
                reservation
            JOIN 
                sleeping_room ON reservation.roomId = sleeping_room.sleepingRoomId
            WHERE 
                reservation.roomId LIKE 'SR%' 
            GROUP BY 
                sleeping_room.sleepingRoomRate
            ORDER BY 
                Reservation_Count DESC;
        """,
        "Revenue by Smoking vs. Non-Smoking Rooms": """
            SELECT 
                CASE 
                    WHEN f.smoke = 1 THEN 'Smoking Room'
                    ELSE 'Non-Smoking Room'
                END AS RoomType,
                SUM(r.deposit) AS TotalRevenue
            FROM 
                reservation r
            JOIN 
                sleeping_room sr ON r.roomId = sr.sleepingRoomId
            JOIN 
                floor f ON sr.floorId = f.floorId
            GROUP BY 
                f.smoke
            ORDER BY 
                TotalRevenue DESC;
        """,
        "Peak Check-In Times by Time Slot": """
            SELECT 
                CASE 
                    WHEN HOUR(r.checkInDate) BETWEEN 0 AND 5 THEN '0-6am'
                    WHEN HOUR(r.checkInDate) BETWEEN 6 AND 11 THEN '6am-12pm'
                    WHEN HOUR(r.checkInDate) BETWEEN 12 AND 17 THEN '12-6pm'
                    WHEN HOUR(r.checkInDate) BETWEEN 18 AND 23 THEN '6pm-12am'
                END AS TimePeriod,
                COUNT(r.reservationId) AS ReservationCount
            FROM 
                reservation r
            GROUP BY 
                TimePeriod
            ORDER BY 
                ReservationCount DESC;
        """
    },
    "customer": {
        "Reservation Counts Per Month in 2023": """
            SELECT 
                DATE_FORMAT(reservation.checkInDate, '%Y-%m') AS Month,
                COUNT(*) AS Total_Reservations
            FROM 
                reservation
            WHERE 
                YEAR(reservation.checkInDate) = 2023
            GROUP BY 
                DATE_FORMAT(reservation.checkInDate, '%Y-%m')
            ORDER BY 
                Month;
        """,
        "Total Reservations Per Customer (Top 5)": """
            SELECT 
                guest.guestName AS Guest_Name,
                COUNT(reservation.reservationId) AS Total_Reservations
            FROM 
                guest
            JOIN 
                reservation ON guest.guestId = reservation.bookerId
            GROUP BY 
                guest.guestId
            ORDER BY 
                Total_Reservations DESC
            LIMIT 5;
        """,
        "Payment Methods by Customers": """
            SELECT 
                billing.paymentMethod AS Payment_Method,
                COUNT(*) AS Usage_Count
            FROM 
                billing
            GROUP BY 
                billing.paymentMethod
            ORDER BY 
                Usage_Count DESC;
        """
    },
    "other": {
        "Comparison of Total Revenue Between Room Types": """
            SELECT 
                combined_room.roomType AS Room_Type,
                SUM(CASE 
                    WHEN combined_room.roomType = 'sleeping' THEN sleeping_room.sleepingRoomRate * DATEDIFF(reservation.checkOutDate, reservation.checkInDate)
                    WHEN combined_room.roomType = 'meeting' THEN meeting_room.meetingRoomRate * DATEDIFF(reservation.checkOutDate, reservation.checkInDate)
                END) AS Total_Revenue
            FROM 
                reservation
            JOIN 
                combined_room ON reservation.roomId = combined_room.roomId
            LEFT JOIN 
                sleeping_room ON reservation.roomId = sleeping_room.sleepingRoomId
            LEFT JOIN 
                meeting_room ON reservation.roomId = meeting_room.meetingRoomId
            GROUP BY 
                combined_room.roomType
            ORDER BY 
                Total_Revenue DESC;
        """,
        "Revenue Contribution by Each Event": """
            SELECT 
                e.eventId AS EventID,
                e.eventDate AS EventDate,
                SUM(mr.meetingRoomRate) AS TotalRevenue
            FROM 
                event e
            JOIN 
                meeting_room mr ON e.meetingRoomId = mr.meetingRoomId
            GROUP BY 
                e.eventId, e.eventDate
            ORDER BY 
                TotalRevenue DESC;
        """,
        "Revenue from Services in February": """
            SELECT 
                s.type AS ServiceType,
                SUM(s.charge) AS TotalRevenue
            FROM 
                service s
            JOIN 
                room_guest rg ON s.associatedRoomId = rg.roomId
            WHERE 
                MONTH(rg.moveInDateTime) = 2 OR MONTH(rg.moveOutDateTime) = 2
            GROUP BY 
                s.type
            ORDER BY 
                TotalRevenue DESC;
        """,
        "Average Length of Stay by Room Type": """
            SELECT 
                sr.furnitureDescription AS RoomType,
                AVG(TIMESTAMPDIFF(DAY, r.checkInDate, r.checkOutDate)) AS AverageStayDuration
            FROM 
                reservation r
            JOIN 
                sleeping_room sr ON r.roomId = sr.sleepingRoomId
            GROUP BY 
                sr.furnitureDescription
            ORDER BY 
                AverageStayDuration DESC;
        """
    }
}
