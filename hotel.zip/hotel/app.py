from flask import Flask, render_template
import mysql.connector
from queries import queries


app = Flask(__name__)


mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="CAS!2345",
    database="hotel"
)


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/room')
def room():
    results = {}
    cursor = mydb.cursor(dictionary=True)

    for query_name, query_sql in queries['room'].items():
        cursor.execute(query_sql)
        results[query_name] = cursor.fetchall()

    return render_template('room.html', results=results)


@app.route('/customer')
def customer():
    results = {}
    cursor = mydb.cursor(dictionary=True)

    for query_name, query_sql in queries['customer'].items():
        cursor.execute(query_sql)
        results[query_name] = cursor.fetchall()

    return render_template('customer.html', results=results)


@app.route('/other')
def other():
    results = {}
    cursor = mydb.cursor(dictionary=True)

    for query_name, query_sql in queries['other'].items():
        cursor.execute(query_sql)
        results[query_name] = cursor.fetchall()

    return render_template('other.html', results=results)

@app.errorhandler(Exception)
def handle_error(e):

    return render_template('error.html', error=e)

if __name__ == "__main__":
    app.run(debug=True, port=5001)
